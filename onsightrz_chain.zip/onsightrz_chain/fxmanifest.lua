fx_version 'cerulean'
game 'gta5'

-- ClothingForge addon: osrz_chain_m_ebaca0f758

files {
    'mp_m_freemode_01_osrz_chain_m_ebaca0f758.meta',
}

data_file 'SHOP_PED_APPAREL_META_FILE' 'mp_m_freemode_01_osrz_chain_m_ebaca0f758.meta'

client_script 'chain_preview.lua'
